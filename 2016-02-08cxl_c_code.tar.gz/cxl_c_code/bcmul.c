#include "stdio.h"
void bcmul(ar,ai,br,bi,m,n,k,cr,ci)
int m,n,k;
double ar[],ai[],br[],bi[],cr[],ci[];
{ int i,j,l,u,v,w;
    double p,q,s;
    for (i=0; i<=m-1; i++)
    for (j=0; j<=k-1; j++)
      { u=i*k+j;
        cr[u]=0.0; ci[u]=0.0;
        for (l=0; l<=n-1; l++)
          { v=i*n+l; w=l*k+j;
            p=ar[v]*br[w];
            q=ai[v]*bi[w];
            s=(ar[v]+ai[v])*(br[w]+bi[w]);
            cr[u]=cr[u]+p-q;
            ci[u]=ci[u]+s-p-q;
          }
      }
    return;
}
main()
{    int i,j;
     static double cr[3][4],ci[3][4];
     static double ar[3][4]={ {1.0,2.0,3.0,-2.0},
            {1.0,5.0,1.0,3.0},{0.0,4.0,2.0,-1.0}};
     static double ai[3][4]={ {1.0,-1.0,2.0,1.0},
            {-1.0,-1.0,2.0,0.0},{-3.0,-1.0,2.0,2.0}};
     static double br[4][4]={ {1.0,4.0,5.0,-2.0},
            {3.0,0.0,2.0,-1.0},{6.0,3.0,1.0,2.0},
            {2.0,-3.0,-2.0,1.0}};
     static double bi[4][4]={ {-1.0,-1.0,1.0,1.0},
            {2.0,1.0,0.0,5.0},{-3.0,2.0,1.0,-1.0},
            {-1.0,-2.0,1.0,-2.0}};
     bcmul(ar,ai,br,bi,3,4,4,cr,ci);
     for (i=0; i<=2; i++)
       { for (j=0; j<=3; j++)
           printf("%13.7e ",cr[i][j]);
         printf("\n");
       }
     printf("\n");
     for (i=0; i<=2; i++)
       { for (j=0; j<=3; j++)
           printf("%13.7e ",ci[i][j]);
         printf("\n");
       }
}