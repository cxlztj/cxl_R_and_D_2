'succ'
class C(object):
    foo  = 101
print C.foo
C.foo=C.foo+1
print C.foo

