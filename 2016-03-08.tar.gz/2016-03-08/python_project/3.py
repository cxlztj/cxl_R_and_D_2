'has bugs'
class InstCt(object):
     count = 30
def __init__ (self):
     print 'initialized'
     InstCt.count += 3
def __del__ (self):
     print 'deleted'
'def howMany(self):'
'     return InstCt.count  '
     
a = InstCt() 
print InstCt.count
b = InstCt()

'b.howMany()'
'a.howMany()'
'del b'
'del c'
print InstCt.count
