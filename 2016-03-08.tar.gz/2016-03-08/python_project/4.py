'succ'
class C(object):
   count = 2
   def __init__ (self):
        print 'initialized'
        C.count += 2
   def __del__ (self):
        print 'deleted'
   def fun(self):
        print 'fun' 
        C.count += 20      
C1=C()
print C.count
C1.fun()
C2=C()
print C.count
C3=C()
print C.count
