class AddrBookEntry(object):
      def __init__(self,nm,ph):
          self.name=nm
          self.phone=ph
          print 'Create instance for:',self.name
      def updatePhone(self,newph):
          self.phone=newph
          print 'Updated phone# for:',self.name

john=AddrBookEntry('John Doe','408-555-1212')
jane=AddrBookEntry('Jane Doe','650-555-1212')
print john
print john.name
print john.phone
print jane
print jane.name
print jane.phone
john.updatePhone('415-555-1212')
print john.phone