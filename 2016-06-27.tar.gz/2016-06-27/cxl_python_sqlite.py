the part of comments needs to be tested by cxl.

import sqlite3
conn=sqlite3.connect('c:\\Python27\\cxl.db')
cu=conn.cursor()

#sql_del="DROP TABLE cxltable;" 
#cu.execute(sql_del)
#conn.commit()

#sql_add="CREATE TABLE cxltable(i INTEGER,name VARCHAR(32));"
#cu.execute(sql_add)
#conn.commit()

#sql_query="SELECT * FROM cxltable;"
#cu.execute(sql_query)
#conn.commit()


#sql_insert="INSERT INTO cxltable(1��'mac');"
#cu.execute(sql_insert)
#conn.commit()

