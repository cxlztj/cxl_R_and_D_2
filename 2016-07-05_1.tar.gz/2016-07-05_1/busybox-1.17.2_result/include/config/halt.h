#define CONFIG_HALT 1
