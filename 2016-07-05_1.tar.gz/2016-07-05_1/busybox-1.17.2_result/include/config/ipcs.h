#define CONFIG_IPCS 1
