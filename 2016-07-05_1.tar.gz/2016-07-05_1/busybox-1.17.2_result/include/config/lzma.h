#define CONFIG_LZMA 1
