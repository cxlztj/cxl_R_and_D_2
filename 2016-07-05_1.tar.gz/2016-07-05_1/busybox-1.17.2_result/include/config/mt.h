#undef CONFIG_MT
