#define CONFIG_STTY 1
