#define CONFIG_TEE 1
