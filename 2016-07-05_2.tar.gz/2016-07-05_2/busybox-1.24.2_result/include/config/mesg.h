#define CONFIG_MESG 1
