#define CONFIG_IFUPDOWN_IFSTATE_PATH "/var/run/ifstate"
