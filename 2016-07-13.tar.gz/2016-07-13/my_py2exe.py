

# my_py2exe.py 

from distutils.core import setup 

import py2exe
setup(console=["hello.py"]) 

